iceybones Scheduler - A simple customer and appointment management application.
Author: Christopher Griswold - cgrisw4@wgu.edu
Version: 1.0
Date: 05/06/2021
IDE: IntelliJ Community 2021.1.1
JDK: openjdk version "11.0.8" 2020-07-14 LTS
JavaFX: JavaFX-SDK-11.0.2
MySQL Connector: mysql-connector-java-8.0.22
How to run on Windows: With Java 11 installed, simply double click the Launcher_WIN.jar file
How to run on Linux: With Java 11 installed, open a terminal at this directory and run the command "java -jar Launcher.jar"
How to run inside IntelliJ: With all the necessary componens installed and configured, create a new run configuration and 
	add the following VM options "--module-path $PATH_TO_FX --add-modules javafx.controls,javafx.fxml". Press the green RUN icon.
The additional report that is included in the reporting dashboard is a visual representation of the relative time each contact has spent in meetings(appointments). In essence this illustrates who is putting the most time in and who may be slaking off.
NOTE: Use the clock button in the upper right of the application window to view appointments by month and week. TIP: Hover over buttons to vew a tooltip explaining their function.
